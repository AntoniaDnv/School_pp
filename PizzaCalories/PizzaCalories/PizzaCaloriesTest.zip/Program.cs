﻿namespace PizzaCalories
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string[] pizzaInput = Console.ReadLine().Split();
                if (pizzaInput.Length < 2)
                {
                    Console.WriteLine("Invalid pizza input.");
                    return;
                }
                Pizza pizza = new Pizza(pizzaInput[1]);

                string[] doughInput = Console.ReadLine().Split();
                if (doughInput.Length < 4)
                {
                    Console.WriteLine("Invalid dough input.");
                    return;
                }
                Dough dough = new Dough(doughInput[1], doughInput[2], double.Parse(doughInput[3]));
                pizza.Dough = dough;

                string input;
                while ((input = Console.ReadLine()) != "END")
                {
                    string[] toppingInput = input.Split();
                    if (toppingInput.Length < 3)
                    {
                        Console.WriteLine("Invalid topping input.");
                        return;
                    }
                    Topping topping = new Topping(toppingInput[1], double.Parse(toppingInput[2]));
                    pizza.AddTopping(topping);
                }

                Console.WriteLine($"{pizza.Name} - {pizza.GetTotalCalories():F2} Calories.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
