﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Storehouse.Enums
{
    public enum ElectronicType
    {
        TV = 0,
        SmartPhone = 1,
        Computer = 2,
        Appliance = 3
    }
}
