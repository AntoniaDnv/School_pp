﻿using Storehouse.Enums;

namespace Storehouse.Items
{
    public class ElectronicItem
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public double Weight { get; set; }
        public string Brand { get; set; }
        public int WarrantyYears { get; set; }
        public ElectronicType Type { get; set; }

        public ElectronicItem(string name, double price, double weight, string brand, int warrantyYears, ElectronicType type)
        {
            Name = name;
            Price = price;
            Weight = weight;
            Brand = brand;
            WarrantyYears = warrantyYears;
        }
    }
}
