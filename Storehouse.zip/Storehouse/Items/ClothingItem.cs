﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Storehouse.Items
{
    public class ClothingItem
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public double Weight { get; set; }
        public string Brand { get; set; }
        public int WarrantyYears { get; set; }
        public string Material { get; set; }
        public string Size { get; set; }
     

        public ClothingItem(string name, double price, double weight,string brand,int warrantyYears, string material, string size)
        {
            Name = name;
            Price = price;
            Weight = weight;
            Brand = brand;
            WarrantyYears = warrantyYears;
            Material = material;
            Size = size;
        }
    }
}
