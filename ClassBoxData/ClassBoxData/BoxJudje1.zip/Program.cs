﻿using System.ComponentModel.DataAnnotations;

namespace ClassBoxData
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int length = int.Parse(Console.ReadLine());
            int width = int.Parse(Console.ReadLine());
            int height = int.Parse(Console.ReadLine());
            var box = new Box(length, width, height);

            box.CalculateArea();
            box.CalculateLateralArea();
            box.CalculateVolume();
        }
    }
}
