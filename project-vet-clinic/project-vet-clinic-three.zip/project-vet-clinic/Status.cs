﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_vet_clinic
{
    public enum Status
    {
        NotAdopted,
        Adopted
    }

}
