﻿using Fields;
using Microsoft.VisualBasic;

namespace CarManifacturer
{
    internal class Program
    {
        static void Main(string[] args)
        {
           Car car = new Car();

            car.Make = "VM";
            car.Model = "MK3";
            car.Yea = 1992;

            Console.WriteLine($"Make: {car.Make}\nModel: {car.Model}\nYea: {car.Yea}");


        }
    }
}